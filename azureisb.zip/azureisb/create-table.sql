create table [dbo].[absensi](
    id INT NOT NULL IDENTITY(1,1) PRIMARY KEY(id),
    nama VARCHAR(50),
    nim VARCHAR(50),
    nik VARCHAR(50),
    date DATE
);
